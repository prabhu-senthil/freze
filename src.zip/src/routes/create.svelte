<div class="container items-center px-5 py-12 ">
    <form class="flex flex-col w-full p-10 px-8 pt-6 mx-auto my-6 mb-4  border rounded-lg lg:w-1/2 ">
  
      <div class=" pt-4">
        <label for="firstname" class="text-base leading-7 text-blueGray-500">First Name</label>
        <input type="text" id="fname" name="firstname" placeholder="First Name" class="w-full px-4 py-2 mt-2 mr-4 text-base text-black border bg-gray-100 rounded-lg">
      </div>
      <div class=" pt-4">
        <label for="name" class="text-base leading-7 text-blueGray-500">Last Name</label>
        <input type="text" id="lname" name="lastname" placeholder="Last Name" class="w-full px-4 py-2 mt-2 mr-4 text-base text-black border bg-gray-100 rounded-lg">
      </div>
      <div class=" pt-4">
        <label for="id" class="text-base leading-7 text-blueGray-500">ID</label>
        <input type="text" id="id" name="id" placeholder="Enter ID" class="w-full px-4 py-2 mt-2 mr-4 text-base text-black border bg-gray-100 rounded-lg">
      </div>
      <div class=" pt-4">
        <label for="email" class="text-base leading-7 text-blueGray-500">Email</label>
        <input type="text" id="email" name="email" placeholder="Email" class="w-full px-4 py-2 mt-2 mr-4 text-base text-black border bg-gray-100 rounded-lg">
      </div>
     
      
      <div class="flex items-center w-full pt-4 mb-4">
        <button class="w-full py-3 text-base text-white   bg-blue-600 border-blue-600 rounded-md  "> Create </button>
      </div>
     
    </form>
  </div>