<aside class="w-64">
   <div class=" py-4 px-3 border-r ">
      <ul class="text-xl" >
         <li>
            <a href="#" class="flex  p-2  text-gray-500 hover:text-gray-900  rounded-lg hover:bg-indigo-100 ">
               <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mt-1.5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
                </svg>
               <span class="ml-3">Home</span>
            </a>
         </li>
         <li>
            <a href="#" class="flex  p-2  text-gray-500 hover:text-gray-900 rounded-lg  hover:bg-indigo-100 ">
               <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mt-1.5" viewBox="0 0 20 20" fill="currentColor">
                  <path fill-rule="evenodd" d="M6 2a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2V7.414A2 2 0 0015.414 6L12 2.586A2 2 0 0010.586 2H6zm2 10a1 1 0 10-2 0v3a1 1 0 102 0v-3zm2-3a1 1 0 011 1v5a1 1 0 11-2 0v-5a1 1 0 011-1zm4-1a1 1 0 10-2 0v7a1 1 0 102 0V8z" clip-rule="evenodd" />
                </svg>
               <span class=" ml-3 ">Dashboard</span>
            </a>
         </li>
         <li>
            <a href="#" class="flex  p-2  text-gray-500 hover:text-gray-900 rounded-lg  hover:bg-indigo-100 ">
               <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mt-1.5" viewBox="0 0 20 20" fill="currentColor">
                  <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" />
                </svg>
               <span class=" ml-3">About</span>
            </a>
         </li>
         <li>
            <a href="#" class="flex  p-2   text-gray-500 hover:text-gray-900 rounded-lg  hover:bg-indigo-100 ">
               <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mt-1.5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
                </svg>
               <span class=" ml-3 ">Contact</span>
            </a>
         </li>
      
      </ul>
   </div>
</aside>